import arcpy
import pythonaddins

class cmBox(object):
    """Implementation for Layer_List_addin.combobox (ComboBox)"""
    def __init__(self):
        #self.items = ["item1", "item2","item3","item4","item5","item6","item7"]
        self.editable = True
        self.enabled = True
        self.dropdownWidth = '123456789123456789123456789123456789123456789123456789'
        self.width = '123456789123456789123456789'
    def onSelChange(self, selection):
        fname = arcpy.ListFields(selection)
        print('Selected Layer is : ',selection)
        j = 1
        for f in fname:
            print(' {0} : name : {1}, Type : {2}, Length : {3}'.format(j,f.name, f.type, f.length))
            j+=1
        #print('selected layer is : ',selection)
    def onEditChange(self, text):
        #print('edit value is :',text)
        pass
    def onFocus(self, focused):
        # When the combo box has focus, update the combo box with the list of layer names.
	if focused:
	    self.mxd = arcpy.mapping.MapDocument('current')
	    layers = arcpy.mapping.ListLayers(self.mxd)
	    self.items = []
	    for layer in layers:
		self.items.append(layer.name)
	#print('layer name',self.layer1)

    def onEnter(self):
        #print('Entered value is :',self.value)
        pass
    def refresh(self):
        pass
